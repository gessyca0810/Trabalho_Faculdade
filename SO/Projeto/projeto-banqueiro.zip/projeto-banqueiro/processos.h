#ifndef SISTEMA_H_INCLUDED   /* Include guard */
#define SISTEMA_H_INCLUDED

void *processos(void *argumento);

#endif // SISTEMA_H_INCLUDED