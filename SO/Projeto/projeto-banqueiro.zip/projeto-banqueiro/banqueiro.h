#ifndef BANQUEIRO_H_INCLUDED   /* Include guard */
#define BANQUEIRO_H_INCLUDED

int liberaRec(int pID,int liberacao[]);
int obterRec(int pID,int requisicao[]);

#endif // BANQUEIRO_H_INCLUDED